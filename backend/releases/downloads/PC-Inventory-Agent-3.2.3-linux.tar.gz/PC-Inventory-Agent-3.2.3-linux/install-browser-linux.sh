#!/bin/sh
# Templates are generated during packaging; no Python or config import is required here.
set -eu
[ "$(id -u)" = 0 ] || { echo 'Run as root.' >&2; exit 1; }
SOURCE=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
BINARY=${1:-}
MANIFESTS=${2:-$SOURCE/native-hosts}
[ -f "$BINARY" ] || { echo 'Pass the extracted native host binary.' >&2; exit 1; }
for browser in chrome edge firefox; do [ -f "$MANIFESTS/$browser.json" ] || { echo 'Native-host templates missing. Extract the full release archive.' >&2; exit 1; };done
BASE=/opt/pc-inventory
[ ! -L "$BASE" ] && [ ! -L "$BASE/inventory-browser-host" ] || { echo 'Refusing symlink';exit 1; }
install -d -m 0755 "$BASE"
install -m 0755 "$BINARY" "$BASE/inventory-browser-host"
for directory in /etc/opt/chrome/native-messaging-hosts /etc/chromium/native-messaging-hosts; do
 install -d -m 0755 "$directory"
 install -m 0644 "$MANIFESTS/chrome.json" "$directory/dk.flyingfish.inventory.browser.json"
done
install -d -m 0755 /etc/opt/edge/native-messaging-hosts /usr/lib/mozilla/native-messaging-hosts
install -m 0644 "$MANIFESTS/edge.json" /etc/opt/edge/native-messaging-hosts/dk.flyingfish.inventory.browser.json
install -m 0644 "$MANIFESTS/firefox.json" /usr/lib/mozilla/native-messaging-hosts/dk.flyingfish.inventory.browser.json
echo 'Browser bridge registered for Chrome, Chromium, Edge and Firefox.'
