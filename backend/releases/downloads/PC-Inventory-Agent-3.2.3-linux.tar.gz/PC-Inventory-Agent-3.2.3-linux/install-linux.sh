#!/bin/sh
# Run as root from an extracted V3 release directory. Existing identity is preserved.
set -eu
[ "$(id -u)" = 0 ] || { echo 'Run as root'; exit 1; }
SOURCE=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
BASE=/opt/pc-inventory
CONFIG=/etc/pc-inventory/agent.json
ACCOUNT=pc-inventory
# Preserve a pre-existing dedicated systemd service identity.
PREVIOUS_ACCOUNT=$(systemctl show FlyingFishInventory.service -p User --value 2>/dev/null || true)
if [ -n "$PREVIOUS_ACCOUNT" ]; then
 case "$PREVIOUS_ACCOUNT" in root|0|*[!a-zA-Z0-9_-]*) echo 'Existing service needs an explicit low privilege account migration.';exit 1;; esac
 ACCOUNT=$PREVIOUS_ACCOUNT
fi
case "$(uname -m)" in x86_64) ARCH=amd64;; aarch64|arm64) ARCH=arm64;; *) echo 'Unsupported architecture';exit 1;; esac
for binary in inventory-agent-linux-$ARCH inventory-launcher-linux-$ARCH inventory-browser-host-linux-$ARCH; do
 [ -f "$SOURCE/$binary" ] || { echo "Missing release file: $binary";exit 1; }
done
[ -f "$SOURCE/install-browser-linux.sh" ] || { echo 'Extract the full release archive.';exit 1; }
for target in "$BASE" /etc/pc-inventory /var/lib/pc-inventory /var/lib/flyingfish-inventory "$CONFIG"; do [ ! -L "$target" ] || { echo 'Refusing symlink';exit 1; };done
id "$ACCOUNT" >/dev/null 2>&1 || useradd --system --user-group --home /var/lib/pc-inventory --shell /usr/sbin/nologin "$ACCOUNT"
ACCOUNT_GROUP=$(id -gn "$ACCOUNT")
install -d -m 0755 "$BASE" /etc/pc-inventory
install -d -m 0700 -o "$ACCOUNT" -g "$ACCOUNT_GROUP" /var/lib/pc-inventory /var/lib/flyingfish-inventory
# Generate public settings only; preserve existing identity/configuration on upgrades.
if [ ! -f "$CONFIG" ]; then
 "$SOURCE/inventory-agent-linux-$ARCH" -config "$CONFIG" -init-config -server "${INV_SERVER:-https://itsm.governit.dk/inventory}" -state-dir /var/lib/pc-inventory
fi
chown "$ACCOUNT:$ACCOUNT_GROUP" "$CONFIG";chmod 0600 "$CONFIG"
# Validate before stopping the existing service or replacing either binary.
"$SOURCE/inventory-agent-linux-$ARCH" -config "$CONFIG" -check-config
# Create a device-local TLS identity. Only the public certificate is browser-readable.
for entry in /etc/pc-inventory/bridge /etc/pc-inventory/bridge/private /etc/pc-inventory/bridge/cert.pem /etc/pc-inventory/bridge/private/key.pem; do
 [ ! -L "$entry" ] || { echo 'Refusing browser identity symlink';exit 1; }
done
install -d -m 0755 /etc/pc-inventory/bridge
install -d -m 0711 /etc/pc-inventory/bridge/private
"$SOURCE/inventory-agent-linux-$ARCH" -init-browser-tls
chown root:root /etc/pc-inventory/bridge/cert.pem
chmod 0644 /etc/pc-inventory/bridge/cert.pem
chown "$ACCOUNT:$ACCOUNT_GROUP" /etc/pc-inventory/bridge/private/key.pem
chmod 0600 /etc/pc-inventory/bridge/private/key.pem
# Stop the existing service before replacing either binary.
systemctl stop FlyingFishInventory.service 2>/dev/null || true
install -m 0755 "$SOURCE/inventory-agent-linux-$ARCH" "$BASE/inventory-agent"
install -m 0755 "$SOURCE/inventory-launcher-linux-$ARCH" "$BASE/inventory-launcher"
"$BASE/inventory-agent" -config "$CONFIG" -check-config
install -d -m 0755 /etc/systemd/system
cat > /etc/systemd/system/FlyingFishInventory.service <<UNIT
[Unit]
Description=PC Inventory Agent
After=network-online.target
Wants=network-online.target
[Service]
User=$ACCOUNT
Group=$ACCOUNT_GROUP
ExecStart=$BASE/inventory-launcher -config $CONFIG
Restart=always
RestartSec=10
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
ReadWritePaths=/var/lib/pc-inventory /var/lib/flyingfish-inventory
[Install]
WantedBy=multi-user.target
UNIT
/bin/sh "$SOURCE/install-browser-linux.sh" "$SOURCE/inventory-browser-host-linux-$ARCH" "$SOURCE/native-hosts"
systemctl daemon-reload
systemctl enable --now FlyingFishInventory.service
