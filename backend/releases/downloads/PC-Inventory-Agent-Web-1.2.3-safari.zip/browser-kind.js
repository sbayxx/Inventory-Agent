globalThis.PCInventoryBrowser = "safari";
