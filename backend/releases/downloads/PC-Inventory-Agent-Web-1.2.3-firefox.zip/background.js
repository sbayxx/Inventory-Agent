'use strict';
if (typeof importScripts === 'function') importScripts('browser-kind.js','catalog.js','sync.js','core.js');
const api=globalThis.browser??globalThis.chrome;
const Core=globalThis.PCInventoryCore;
const Catalog=globalThis.PCInventoryCatalog;
const STORAGE_KEY='pcInventoryWebState';
let pending=Promise.resolve();
function serialize(task) { const result=pending.then(task);pending=result.catch(()=>{});return result; }
async function load() {
 if(typeof api.storage.local.setAccessLevel==='function')await api.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});
 const value=await api.storage.local.get(STORAGE_KEY);const state=Core.sanitize(value[STORAGE_KEY],Catalog);
 if(!state.sync)state.sync={mode:'agent',client_id:crypto.randomUUID().replaceAll('-',''),revision:0,lastSuccess:null,lastAttempt:0,error:null,agent_id:null};return state;
}
async function save(state) { await api.storage.local.set({[STORAGE_KEY]:state});await badge(state.enabled); }
async function badge(enabled) {
  const action=api.action??api.browserAction;
  try {
    await action.setBadgeText({text:enabled?'ON':'OFF'});
    await action.setBadgeBackgroundColor({color:enabled?'#087f70':'#637082'});
    await action.setTitle({title:`PC Inventory Agent · ${enabled?'Registrerer og sender via computerens agent':'Registrering er slået fra'}`});
  } catch { /* Safari badge availability can differ; popup status remains visible. */ }
}
async function synchronize(state) {
  if(!state.enabled)return;
  state.sync.revision=Math.max(state.sync.revision+1,Date.now());state.sync.lastAttempt=Date.now();await save(state);
  try{
    const browserName=globalThis.PCInventoryBrowser;
    const result=await api.runtime.sendNativeMessage('dk.flyingfish.inventory.browser',{client_id:state.sync.client_id,browser:browserName,scan:PCInventorySync.payload(state)});
    if(result?.ok===true&&result.accepted===true&&result.revision===state.sync.revision&&/^[a-f0-9]{32}$/.test(result.agent_id)){
      state.sync.lastSuccess=new Date().toISOString();state.sync.error=null;state.sync.agent_id=result.agent_id;
    }else{state.sync.error=['network','unauthorized','server','agent_missing'].includes(result?.error)?result.error:'server';}
  }catch{state.sync.error='agent_missing';}finally{await save(state);}
}
function initialize(send=false) { return serialize(async()=>{const state=await load();await save(state);await api.alarms.create('pc-inventory-sync',{periodInMinutes:15});if(send)await synchronize(state);}); }
api.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='pc-inventory-sync')serialize(async()=>{const state=await load();await synchronize(state);}).catch(()=>{});});
api.runtime.onInstalled.addListener(()=>{initialize(true).catch(()=>{});});
api.runtime.onStartup.addListener(()=>{initialize(true).catch(()=>{});});
api.webNavigation.onCompleted.addListener(details=>{
  if (details.frameId!==0 || details.tabId<0) return;
  if (details.documentLifecycle && details.documentLifecycle!=='active') return;
  serialize(async()=>{
    let tab;try{tab=await api.tabs.get(details.tabId);}catch{return;}
    if (!tab || tab.incognito!==false) return; // Fail closed when privacy state is unavailable.
    const state=await load();
    const recorded=Core.record(state,details.url,Catalog);
    await save(state);
    if(recorded&&!state.sync.lastSuccess&&Date.now()-state.sync.lastAttempt>60000)await synchronize(state);
  }).catch(()=>{});
},{url:[{schemes:['http','https']}]});
api.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if (sender.id!==api.runtime.id || typeof sender.url!=='string' || !sender.url.startsWith(api.runtime.getURL(''))) return false;
  serialize(async()=>{
    const state=await load();
    switch(message?.type) {
      case 'get':break;
      case 'sync-now':if(!state.enabled)throw new Error('Registrering er på pause.');await synchronize(state);break;
      case 'settings':Core.settings(state,message.settings,Catalog);break;
      case 'rule':Core.putRule(state,message.domain,message.category,Catalog);break;
      case 'delete-rule':
        state.overrides=state.overrides.filter(rule=>rule.domain!==message.domain);Core.reclassify(state,Catalog);break;
      case 'clear':state.records=[];state.dropped=0;break;
      default:throw new Error('Ukendt handling.');
    }
    await save(state);return {ok:true,state,categories:Catalog.categories,catalogVersion:Catalog.version};
  }).then(sendResponse).catch(()=>sendResponse({ok:false,error:'Handlingen kunne ikke gennemføres. Kontrollér indstillinger og browserens lagerplads.'}));
  return true;
});
