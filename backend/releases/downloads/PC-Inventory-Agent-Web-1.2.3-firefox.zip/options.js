(() => {
  'use strict';
  const api=globalThis.browser??globalThis.chrome;
  const Core=globalThis.PCInventoryCore;
  const Catalog=globalThis.PCInventoryCatalog;
  const labels=new Map(Catalog.categories.map(c=>[c.id,c.label]));
  const collator=new Intl.Collator('da',{numeric:true,sensitivity:'base'});
  let state=Core.initial(),filtered=[],page=1;
  const $=id=>document.getElementById(id);
  const say=message=>{$('notice').textContent=message;$('error').textContent='';};
  function cell(value){const td=document.createElement('td');td.textContent=String(value);return td;}
  for(const category of Catalog.categories){
    for(const id of ['filter-category','rule-category']){const option=document.createElement('option');option.value=category.id;option.textContent=category.label;$(id).append(option);}
  }
  for(const rule of [...Catalog.rules].sort((a,b)=>collator.compare(a.domain,b.domain))){const tr=document.createElement('tr');tr.append(cell(rule.domain),cell(labels.get(rule.category)));$('catalog-rules').append(tr);}
  $('catalog-info').textContent=`${Catalog.rules.length} standardregler · katalog ${Catalog.version}. Kategorien er et domænebaseret skøn, ikke en vurdering af sidens sikkerhed.`;
  async function command(message){
    const response=await api.runtime.sendMessage(message);
    if(!response?.ok)throw new Error(response?.error??'Udvidelsens lager kunne ikke læses.');
    state=response.state;renderSettings();render();return response;
  }
  function renderSettings(){
    $('sync-now').disabled=!state.enabled;
    const errors={agent_missing:'PC Inventory Agent med browserbro blev ikke fundet. Installér den nye agentpakke og kontrollér, at tjenesten kører.',network:'Forbindelsen til ITSM mislykkedes; forsøger igen senere.',unauthorized:'ITSM har afvist eller tilbagekaldt uploadadgangen.',server:'ITSM afviste data, eller browsermodulet er deaktiveret.'};
    $('sync-status').textContent=`${state.enabled?'Automatisk overførsel aktiv':'Registrering og overførsel på pause'} · Senest sendt: ${state.sync?.lastSuccess??'aldrig'}${state.sync?.agent_id?' · Enhed: '+state.sync.agent_id.slice(0,8):''}. ${errors[state.sync?.error]??''}`;
    $('enabled').checked=state.enabled;$('retention').value=String(state.retentionDays);$('excluded').value=state.excludedDomains.join('\n');
    $('status').textContent=state.enabled?'REGISTRERING AKTIV':'REGISTRERING PÅ PAUSE';$('status').classList.toggle('active',state.enabled);
    $('rules').replaceChildren();
    for(const rule of [...state.overrides].sort((a,b)=>collator.compare(a.domain,b.domain))){
      const item=document.createElement('li');const text=document.createElement('span');const button=document.createElement('button');
      text.textContent=`${rule.domain} → ${labels.get(rule.category)}`;button.type='button';button.className='secondary';button.textContent='Fjern';
      button.addEventListener('click',()=>command({type:'delete-rule',domain:rule.domain}).then(()=>say('Lokal regel fjernet.')).catch(showError));item.append(text,button);$('rules').append(item);
    }
    $('no-rules').hidden=state.overrides.length!==0;
    if(state.dropped)$('error').textContent=`Lagergrænsen er nået. ${state.dropped} nye dags-/domæneposter er afvist; eksisterende data er bevaret.`;
  }
  function render(){
    const query=$('search').value.trim().toLocaleLowerCase('da');const category=$('filter-category').value;const period=$('filter-period').value;
    const day=new Date().toISOString().slice(0,10);
    const cutoff=period==='all'?'0000-00-00':new Date(Date.parse(`${day}T00:00:00Z`)-(Number(period)-1)*86400000).toISOString().slice(0,10);
    filtered=state.records.filter(row=>row.day>=cutoff&&row.domain.toLocaleLowerCase('da').includes(query)&&(!category||row.category===category));
    const sort=$('sort').value;
    filtered.sort((a,b)=>{
      let result=0;
      if(sort==='count-desc')result=b.count-a.count;
      if(sort==='domain-asc')result=collator.compare(a.domain,b.domain);
      if(sort==='category-asc')result=collator.compare(labels.get(a.category),labels.get(b.category));
      if(sort==='day-desc')result=collator.compare(b.day,a.day);
      return result||collator.compare(a.domain,b.domain)||collator.compare(b.day,a.day);
    });
    const counts=new Map();for(const row of filtered)counts.set(row.category,(counts.get(row.category)??0)+row.count);
    $('metric-domains').textContent=String(new Set(filtered.map(r=>r.domain)).size);$('metric-visits').textContent=String(filtered.reduce((sum,r)=>sum+r.count,0));$('metric-categories').textContent=String(counts.size);
    $('category-bars').replaceChildren();
    const max=Math.max(1,...counts.values());
    for(const [category,count] of [...counts].sort((a,b)=>b[1]-a[1])){
      const row=document.createElement('div');row.className='bar-row';const label=document.createElement('span');const bar=document.createElement('progress');const number=document.createElement('strong');
      label.textContent=labels.get(category);bar.max=max;bar.value=count;bar.setAttribute('aria-label',`${label.textContent}: ${count}`);number.textContent=String(count);row.append(label,bar,number);$('category-bars').append(row);
    }
    const pages=Math.max(1,Math.ceil(filtered.length/50));page=Math.min(page,pages);
    $('rows').replaceChildren();
    for(const row of filtered.slice((page-1)*50,page*50)){const tr=document.createElement('tr');tr.append(cell(row.day),cell(row.domain),cell(labels.get(row.category)),cell(row.count));$('rows').append(tr);}
    $('count').textContent=`${filtered.length} af ${state.records.length} gemte dags-/domæneposter matcher.`;$('empty').hidden=filtered.length!==0;
    $('page').textContent=`Side ${page} af ${pages}`;$('previous').disabled=page===1;$('next').disabled=page>=pages;
  }
  function showError(error){$('error').textContent=error.message??'Handlingen kunne ikke gennemføres.';}
  $('settings-form').addEventListener('submit',event=>{
    event.preventDefault();command({type:'settings',settings:{enabled:$('enabled').checked,retentionDays:Number($('retention').value),excludedDomains:$('excluded').value.split(/\r?\n/).map(d=>d.trim()).filter(Boolean)}}).then(()=>say('Indstillinger gemt.')).catch(showError);
  });
  $('rule-form').addEventListener('submit',event=>{event.preventDefault();command({type:'rule',domain:$('rule-domain').value.trim(),category:$('rule-category').value}).then(()=>{$('rule-domain').value='';say('Regel gemt. Gemte data er omkategoriseret.');}).catch(showError);});
  for(const id of ['search','filter-category','filter-period','sort'])$(id).addEventListener(id==='search'?'input':'change',()=>{page=1;render();});
  $('previous').addEventListener('click',()=>{page--;render();});$('next').addEventListener('click',()=>{page++;render();});
  $('reset').addEventListener('click',()=>{$('search').value='';$('filter-category').value='';$('filter-period').value='30';$('sort').value='count-desc';page=1;render();});
  $('refresh').addEventListener('click',()=>command({type:'get'}).then(()=>say('Oversigten er opdateret.')).catch(showError));
  $('export').addEventListener('click',()=>{
    const blob=new Blob([Core.csv(filtered,Catalog)],{type:'text/csv;charset=utf-8'});const url=URL.createObjectURL(blob);const link=document.createElement('a');
    link.href=url;link.download=`pc-inventory-web-${new Date().toISOString().slice(0,10)}.csv`;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  $('clear').addEventListener('click',()=>{
    if(!window.confirm('Slet alle lokale registreringer? Det kan ikke fortrydes. Regler og indstillinger bevares.'))return;
    command({type:'clear'}).then(()=>say('Alle lokale registreringer er slettet.')).catch(showError);
  });
  $('sync-now').addEventListener('click',()=>{$('sync-now').disabled=true;command({type:'sync-now'}).then(()=>say(state.sync?.error?'Overførsel mislykkedes. Se forbindelsesstatus.':'Data sendt til ITSM.')).catch(showError);});
  command({type:'get'}).catch(showError);
})();
