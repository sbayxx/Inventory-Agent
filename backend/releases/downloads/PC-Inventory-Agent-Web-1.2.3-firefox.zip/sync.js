(function(root){
 'use strict';
 function sanitize(input){
  if(!input||input.mode!=='agent'||typeof input.client_id!=='string'||!/^[a-f0-9]{32}$/.test(input.client_id))return null;
  return {mode:'agent',client_id:input.client_id,revision:Number.isSafeInteger(input.revision)&&input.revision>=0?input.revision:0,lastSuccess:typeof input.lastSuccess==='string'?input.lastSuccess:null,lastAttempt:Number.isSafeInteger(input.lastAttempt)?input.lastAttempt:0,error:['agent_missing','network','unauthorized','server'].includes(input.error)?input.error:null,agent_id:typeof input.agent_id==='string'&&/^[a-f0-9]{32}$/.test(input.agent_id)?input.agent_id:null};
 }
 function payload(state,now=Date.now()){
  const cutoff=new Date(Date.parse(new Date(now).toISOString().slice(0,10)+'T00:00:00Z')-29*86400000).toISOString().slice(0,10);
  return {schema:1,revision:state.sync.revision,records:state.records.filter(r=>r.day>=cutoff).map(r=>({day:r.day,domain:r.domain,category:r.category,count:r.count}))};
 }
 root.PCInventorySync={sanitize,payload};
 if(typeof module!=='undefined')module.exports=root.PCInventorySync;
})(globalThis);
