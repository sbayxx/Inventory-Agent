globalThis.PCInventoryBrowser = "firefox";
