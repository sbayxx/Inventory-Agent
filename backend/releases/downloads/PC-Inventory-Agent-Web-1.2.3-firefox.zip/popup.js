(() => {
  'use strict';
  const api=globalThis.browser??globalThis.chrome;
  let response;
  const text=(id,value)=>{document.getElementById(id).textContent=String(value);};
  async function refresh(message={type:'get'}) {
    response=await api.runtime.sendMessage(message);
    if (!response?.ok) throw new Error('Kunne ikke læse udvidelsens lokale lager.');
    const {state,categories}=response;
    text('status',state.enabled?'AKTIV':'PAUSE');
    text('sync-status',state.sync?`ITSM-overførsel: ${state.enabled?'aktiv':'pause'} · senest sendt: ${state.sync.lastSuccess??'aldrig'}`:'ITSM: afventer PC Inventory Agent');
    document.getElementById('status').classList.toggle('active',state.enabled);
    text('toggle',state.enabled?'Sæt registrering og overførsel på pause':'Aktivér registrering og overførsel');
    document.getElementById('toggle').disabled=false;
    const today=new Date().toISOString().slice(0,10);
    const records=state.records.filter(row=>row.day===today);
    text('domains',new Set(records.map(row=>row.domain)).size);
    text('visits',records.reduce((sum,row)=>sum+row.count,0));
    const counts=new Map();for(const row of records)counts.set(row.category,(counts.get(row.category)??0)+row.count);
    const labels=new Map(categories.map(c=>[c.id,c.label]));
    const list=document.getElementById('categories');list.replaceChildren();
    for(const [category,count] of [...counts].sort((a,b)=>b[1]-a[1])){
      const item=document.createElement('li');const label=document.createElement('span');const number=document.createElement('strong');
      label.textContent=labels.get(category)??category;number.textContent=String(count);item.append(label,number);list.append(item);
    }
    document.getElementById('empty').hidden=records.length!==0;
    if(state.sync?.error)text('error',state.sync.error==='agent_missing'?'Installér den nye PC Inventory Agent med browserbro. Se forbindelsesstatus i indstillinger.':'Overførsel afventer forbindelse til ITSM. Se indstillinger.');
    if(state.dropped)text('error','Lagergrænsen er nået. Åbn oversigten for at rydde data eller ændre opbevaring.');
  }
  document.getElementById('toggle').addEventListener('click',async()=>{
    document.getElementById('toggle').disabled=true;text('error','');
    try{const state=response.state;await refresh({type:'settings',settings:{enabled:!state.enabled,retentionDays:state.retentionDays,excludedDomains:state.excludedDomains}});}catch{text('error','Indstillingen kunne ikke gemmes.');document.getElementById('toggle').disabled=false;}
  });
  document.getElementById('open').addEventListener('click',()=>{api.runtime.openOptionsPage();});
  refresh().catch(()=>text('error','Kunne ikke indlæse udvidelsen. Prøv at åbne den igen.'));
})();
