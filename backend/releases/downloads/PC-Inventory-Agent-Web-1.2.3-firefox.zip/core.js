(function(root) {
  'use strict';
  const MAX_RECORDS = 5000;
  const BAD_SUFFIXES = ['.local','.localhost','.internal','.lan','.home','.test','.invalid'];
  function domainFrom(value, isURL = true) {
    try {
      if (typeof value !== 'string' || value.length > 16384) return null;
      if (!isURL && /[\s/:?#@\\]/.test(value)) return null;
      const url = new URL(isURL ? value : `https://${value}`);
      if (!['https:','http:'].includes(url.protocol)) return null;
      let domain = url.hostname.toLowerCase().replace(/\.$/,'').replace(/^www\./,'');
      if (domain.length > 253 || !domain.includes('.') || BAD_SUFFIXES.some(suffix=>domain.endsWith(suffix))) return null;
      if (/^[\d.]+$/.test(domain) || domain.includes(':')) return null;
      if (!domain.split('.').every(label=>/^[a-z\d](?:[a-z\d-]{0,61}[a-z\d])?$/.test(label))) return null;
      return domain;
    } catch { return null; }
  }
  function matches(domain, rule) { return domain === rule || domain.endsWith(`.${rule}`); }
  function classify(domain, catalog, overrides = []) {
    for (const rules of [overrides,catalog.rules]) {
      const rule = rules.filter(rule=>matches(domain,rule.domain)).sort((a,b)=>b.domain.length-a.domain.length)[0];
      if (rule) return rule.category;
    }
    return 'uncategorized';
  }
  function initial() {
    return {schema:2,enabled:true,retentionDays:30,excludedDomains:[],overrides:[],records:[],dropped:0,sync:null};
  }
  function validDay(day) {
    return typeof day === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(day) && !Number.isNaN(Date.parse(day)) && new Date(day).toISOString().slice(0,10) === day;
  }
  function prune(state, now = Date.now()) {
    const today = new Date(now).toISOString().slice(0,10);
    const cutoff = new Date(Date.parse(`${today}T00:00:00Z`) - (state.retentionDays-1)*86400000).toISOString().slice(0,10);
    state.records = state.records.filter(row=>row.day>=cutoff && row.day<=today);
    return state;
  }
  function sanitize(raw, catalog, now = Date.now()) {
    const state = initial();
    if (!raw || ![1,2].includes(raw.schema)) return state;
    const categories = new Set(catalog.categories.map(c=>c.id));
    state.sync=root.PCInventorySync?.sanitize(raw.sync)??null;
    state.enabled = raw.schema===1 ? true : raw.enabled === true;
    state.retentionDays = [7,14,30,90].includes(raw.retentionDays) ? raw.retentionDays : 30;
    state.dropped = Number.isSafeInteger(raw.dropped) && raw.dropped>=0 ? raw.dropped : 0;
    state.excludedDomains = [...new Set((Array.isArray(raw.excludedDomains)?raw.excludedDomains:[]).map(d=>domainFrom(d,false)).filter(Boolean))].slice(0,200);
    state.overrides = (Array.isArray(raw.overrides)?raw.overrides:[]).filter(rule=>rule && domainFrom(rule.domain,false) && categories.has(rule.category)).slice(0,200).map(rule=>({domain:domainFrom(rule.domain,false),category:rule.category}));
    state.records = (Array.isArray(raw.records)?raw.records:[]).filter(row=>row && validDay(row.day) && domainFrom(row.domain,false) && categories.has(row.category) && Number.isSafeInteger(row.count) && row.count>0 && row.count<=1000000).slice(0,MAX_RECORDS).map(row=>({day:row.day,domain:domainFrom(row.domain,false),category:row.category,count:row.count}));
    state.records=state.records.filter(row=>!state.excludedDomains.some(rule=>matches(row.domain,rule)));
    return prune(state,now);
  }
  function record(state,url,catalog,now=Date.now()) {
    prune(state,now);
    if (!state.enabled) return false;
    const domain=domainFrom(url);
    if (!domain || state.excludedDomains.some(rule=>matches(domain,rule))) return false;
    const day=new Date(now).toISOString().slice(0,10);
    const category=classify(domain,catalog,state.overrides);
    const existing=state.records.find(row=>row.day===day && row.domain===domain && row.category===category);
    if (existing) { existing.count=Math.min(1000000,existing.count+1);return true; }
    if (state.records.length>=MAX_RECORDS) {state.dropped++;return false;}
    state.records.push({day,domain,category,count:1});return true;
  }
  function settings(state,input,catalog) {
    if (typeof input.enabled !== 'boolean' || ![7,14,30,90].includes(input.retentionDays)) throw new Error('Ugyldige indstillinger.');
    if (!Array.isArray(input.excludedDomains) || input.excludedDomains.length>200) throw new Error('Højst 200 undtagelser.');
    const exclusions=input.excludedDomains.map(value=>domainFrom(value,false));
    if (exclusions.some(value=>!value)) throw new Error('Undtagelser skal være gyldige domæner uden sti eller protokol.');
    state.enabled=input.enabled;state.retentionDays=input.retentionDays;state.excludedDomains=[...new Set(exclusions)];
    // Removing a domain from collection also removes its already stored aggregates.
    state.records=state.records.filter(row=>!state.excludedDomains.some(rule=>matches(row.domain,rule)));
    return prune(state);
  }
  function putRule(state,domain,category,catalog) {
    const normalized=domainFrom(domain,false);
    if (!normalized || !catalog.categories.some(c=>c.id===category)) throw new Error('Vælg et gyldigt domæne og en kategori.');
    if (!state.overrides.some(rule=>rule.domain===normalized) && state.overrides.length>=200) throw new Error('Højst 200 lokale regler.');
    state.overrides=state.overrides.filter(rule=>rule.domain!==normalized);
    state.overrides.push({domain:normalized,category});reclassify(state,catalog);return state;
  }
  function reclassify(state,catalog) {
    const merged=new Map();
    for (const row of state.records) {
      const category=classify(row.domain,catalog,state.overrides);const key=`${row.day}|${row.domain}|${category}`;
      if (!merged.has(key)) merged.set(key,{day:row.day,domain:row.domain,category,count:0});
      const target=merged.get(key);target.count=Math.min(1000000,target.count+row.count);
    }
    state.records=[...merged.values()];return state;
  }
  function csv(rows,catalog) {
    const labels=new Map(catalog.categories.map(c=>[c.id,c.label]));
    const escape=value=>'"'+String(value).replace(/^[=+\-@\t\r]/,"'$&").replaceAll('"','""')+'"';
    return '\uFEFF'+[['Dato (UTC)','Domæne','Kategori','Sideindlæsninger'],...rows.map(r=>[r.day,r.domain,labels.get(r.category)??r.category,r.count])].map(row=>row.map(escape).join(';')).join('\r\n');
  }
  const api={MAX_RECORDS,domainFrom,matches,classify,initial,sanitize,prune,record,settings,putRule,reclassify,csv};
  root.PCInventoryCore=api;
  if (typeof module !== 'undefined') module.exports=api;
})(globalThis);
