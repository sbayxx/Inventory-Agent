# PC Inventory Agent 3

Version 3.2.0 tilføjer et [Windows-statusikon](windows-tray.md) med manuel synkronisering. Installér den fulde nye Windows-pakke én gang for at få ikonet og autostart.

Version 3.1.0 tilføjer [automatisk registrering](device-enrollment.md) uden nøgle-/kodeindtastning. Nye installationer afventer godkendelse i ITSM; eksisterende identiteter bevares. Beskrivelser af unik agent.json nedenfor gælder tidligere udgaver og manuel provisioning.

Version 3 er et selvstændigt modul ved siden af Inventory version 1, version 2 og browserindsamlingen. Hovedsiden er `/inventory/v3.php`. Fem nye tabeller med præfikset `inv_v3_` indeholder enhedspolitikker, opgaver, integrationsnøgler, releaser og revisionslog. Migration 005 er additiv og gentagelig; modulet er slukket ved første migration.

## Første installation og drift

Installer `build/PC-Inventory-Agent-3.0.1-universal.pkg` oven på den eksisterende Mac-installation. Agentidentitet, konfiguration og offlinekø bevares. Pakken registrerer nu en root-ejet launcher, der kører som den samme begrænsede servicekonto. Der kræves én manuel opgradering fra version 1/2, da de udgaver ikke indeholder opdateringsmekanismen. Pakken er fortsat en pilot uden Developer ID/notarisering.

Windows/Linux-udgaverne ligger i `build/PC-Inventory-Agent-3.0.1-windows/` og `build/PC-Inventory-Agent-3.0.1-linux/`. Begge arkitekturer og installationsscripts er inkluderet. Scripts skal køres af en administrator, og en unik `agent.json` skal være provisioneret først. Windows kræver en dedikeret serviceidentitet med service-logon-rettigheder; opgradering bevarer en eksisterende serviceidentitet. Disse to serviceinstallationer skal pilotafprøves på deres respektive operativsystemer.

Åbn **Version 3 → Enheder og fjernsupport**, fold enheden ud og aktiver eventuelt automatiske opdateringer under Agentstyring. Opdateringer er fravalgt som standard. Agentens kontrolkontakt vises på enheden. Første kontakt kræver agent 3.0; ældre agenter fortsætter inventarindsamlingen uændret.

## Signerede agentopdateringer

Launcheren kontrollerer efter ét minut og derefter hvert kvarter, om der er en release til den aktuelle platform/arkitektur. Kun den faste ITSM-server kontaktes via HTTPS, med enhedens egne legitimationsoplysninger, uden redirects. Signatur og metadata kontrolleres før download, derefter størrelse og SHA-256. Versionsnummer skal være nyere end den kørende udgave. Ingen eksterne download-URL'er eller installationskommandoer accepteres fra serveren.

Opdateringen gemmes i servicekontoens beskyttede state-mappe og starter som en ny agentproces med samme rettigheder. Den root-ejede launcher og den medfølgende agent erstattes ikke. Signaturen kontrolleres igen ved start. Hvis den opdaterede proces ikke kan startes eller stopper inden for det første minut, faldes tilbage til den tidligere udgave i den aktuelle launcher-session, ellers til pakkens medfølgende udgave. Den fejlende version spærres lokalt i 24 timer. Tilbagefaldet kontrollerer processtart/-levetid, ikke alle indsamleres funktion. En proces, der fortsætter med at køre men har en logisk fejl, kræver at administrator pauser releasen og publicerer en rettet nyere version.

Tilbagefald og sideordnet installation kræver ikke administratorrettigheder. macOS-signering til Gatekeeper og Windows Authenticode er separate fra Ed25519-kontrollen. Browserudvidelse, native host og launcher opgraderes via installationspakker, ikke denne agentopdatering.

Signeringsnøglen ligger kun lokalt i `.local/release-signing/ed25519.key`, mode 0600. Den skal sikkerhedskopieres sikkert. Den offentlige nøgle i `packaging/release-public-key.txt` indbygges i launcheren. Send aldrig privatnøglen til webhotellet eller læg den i versionsstyring. Rotation af tillidsnøglen kræver en ny installationspakke.

Releaseforløb:

1. Opdatér versionsnummer og byg/test agenter og installationspakker med `scripts/build.sh` og `scripts/build-macos-pkg.sh`.
2. Kør `python3 scripts/prepare-v3-release.py VERSION`. Det signerer de seks platformfiler lokalt og nægter at erstatte en allerede klargjort release. Manifesternes gyldighed for distribution er 90 dage. En allerede verificeret installeret agent fortsætter efter udløbet.
3. Publicér artefakterne i den beskyttede `/backend/inventory/releases/` via normal FTPS. Kontrollér, at HTTP-adgang til privatkataloget er afvist.
4. Registrér hver release med CLI: `php server/bin/inventory.php v3-import-release ENVELOPE BINARY PUBLIC_KEY_FILE`. Publiceringsmaskinen skal have PHP Sodium; signatur, filhash og størrelse verificeres. Webserveren behøver ikke Sodium for at levere releasen.
5. Aktivér releasen under **Agentopdateringer** som global administrator. Start med en pilot, og aktivér derefter opdateringer pr. enhed. Pausering stopper nye tilbud; den afinstallerer ikke allerede anvendte versioner.

Releaseversion/platform/arkitektur er uforanderlig efter import. Agentens normale scan viser den faktisk kørende agentversion; launcheren har separat versionsnummer. Status og fejl står i de eksisterende agentlogs. Konfiguration og kø bevares.

## Fjernopgaver

Administrator og kundeadministrator kan oprette **Scan og send nyt inventar** eller **Send ventende scanninger**. Agenten henter opgaver ca. hvert minut via udgående HTTPS. Der er ingen indgående administrationsport.

Opgaver er bundet til enhed og kunde, gyldige i 24 timer og begrænset til 10 pr. enhed pr. time. En opgave leases i 10 minutter og kan udleveres højst tre gange. Kun enhedens egne legitimationsoplysninger og den aktuelle lease kan kvittere. Gemte kvitteringer forhindrer en ny scanning, når kun kvitteringen skal gensendes. Et nedbrud mellem udførelse og lokal kvitteringslagring kan medføre et gentaget forsøg; dette er ikke en garanti for exactly-once-udførelse. Fjernopgaver har fast handlingstype og accepterer ikke shellkode.

En vellykket opgave betyder, at de ventende scanninger er kvitteret af serveren. Ved leveringsfejl bevares køen, og opgaven markeres fejlet med en kort besked. Ventende opgaver kan annulleres; allerede hentede opgaver kan være i gang. De udføres med den eksisterende servicekontos rettigheder.

## TeamViewer og VNC

Registrér TeamViewer-ID og/eller VNC-vært/IP og port på enheden. ITSM validerer adresserne og gemmer ingen adgangskoder. **Start TeamViewer/VNC** registrerer en anmodning i revisionsloggen og viser et link til jeres eksisterende klient. TeamViewer åbnes via `https://start.teamviewer.com/ID`; installeret klient/version kan påvirke åbningsforløbet. VNC bruger `vnc://vært:port`; operativsystemet skal have en VNC-klient registreret til protokollen, og forbindelsen skal kunne nå enheden, typisk via lokalnet/VPN.

TeamViewer-/VNC-software skal allerede være installeret og korrekt konfigureret. Brugeraccept, autentificering, skærm-/filadgang og sessionslogning følger fjernsupportværktøjet. ITSM opretter ikke en tunnel, åbner ikke firewallporte og kan ikke bekræfte, at en ekstern session faktisk blev gennemført. ITSM-loggen angiver derfor **remote_launch_requested**, ikke en gennemført session. Knapperne skal pilotafprøves med jeres klienter.

Kilder: [TeamViewer forbindelse via ID](https://www.teamviewer.com/en-us/global/support/knowledge-base/teamviewer-remote/remote-control/connect-via-id-and-password/), [Apple VNC](https://support.apple.com/en-au/guide/remote-desktop/apde0dd523e/mac).

## Integration med andre IT-systemer

Under **Integrations-API** opretter en administrator en navngiven nøgle til én kunde. Den vises én gang, gemmes som SHA-256, udløber efter 90 dage og kan tilbagekaldes med det samme. Der er højst 20 aktive nøgler pr. kunde og 120 kald pr. nøgle pr. minut. HTTP 429 returnerer `Retry-After: 60`.

API'et er læsebaseret HTTPS/JSON med skemaversion 1:

- `GET /inventory/v3-integration.php?resource=computers&limit=100` returnerer en oversigt og eventuel `next_cursor`.
- Næste side hentes med `cursor=NEXT_CURSOR`. Enheds-ID er stabilt, hvis agentidentiteten bevares.
- `GET /inventory/v3-integration.php?resource=computer&id=ENHEDS_ID` returnerer senest kendte computer-, hardware-, disk-, netværks-, software- og sikkerhedsdata samt indsamlingsstatus.
- Header: `Authorization: Bearer API_NØGLE`. Nøgler accepteres ikke i URL'en.

Eksempelklienten `integration/pull-inventory.py` henter paginerede data til en lokal JSON-fil. Hemmeligheder indlæses fra miljøvariablen `INV_INTEGRATION_TOKEN`. API'et eksporterer ikke agenttokens, webtrafik eller centrale licensrettigheder. Eksterne systemer skal respektere indsamlingsstatus og måletid: et manglende felt er ikke bevis for fjernet udstyr. Der er ikke konfigureret en leverandørspecifik CMDB-connector eller automatisk overførsel til et unavngivet eksternt system.

## Installation af servermodulet og deaktivering

Kør migration med `php server/bin/inventory.php v3-migrate`, publicér V3-filerne, og aktivér med `v3-enable` eller som global administrator i indstillingerne. Kun offentlige indgangsfiler skal ligge under `/inventory`; PHP-kode, releases, konfiguration og migrationer ligger i det beskyttede backend-katalog.

`v3-disable` eller hovedkontakten i V3-indstillinger lukker integrations-API, fjernopgaver og nye agentopdateringer. De fire funktioner kan også deaktiveres individuelt. Oprindeligt inventar, browsermodul og V2 påvirkes ikke. Allerede åbne TeamViewer-/VNC-sessioner og den aktuelt kørende agent styres ikke af denne kontakt. Ingen eksisterende ITSM-data slettes af migration eller deaktivering.
