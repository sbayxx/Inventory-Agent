#Requires -Version 5.1
#Requires -RunAsAdministrator
param([string]$Server='https://itsm.governit.dk/inventory',[string]$ServiceUser='',[string]$Config='',[switch]$Quiet)
$ErrorActionPreference='Stop'
$InstallerVersion='3.2.2'
$installationLock=$null
trap {
 if($installationLock){$installationLock.Dispose()}
 Write-Error -ErrorRecord $_ -ErrorAction Continue
 try { Show-InventoryInstallMessage -Success $false -Version $InstallerVersion -Quiet:$Quiet } catch { Write-Warning 'Installation failed. See the installer window for details.' }
 exit 1
}
. (Join-Path $PSScriptRoot 'windows-install-functions.ps1')
$machineArch=if($env:PROCESSOR_ARCHITEW6432){$env:PROCESSOR_ARCHITEW6432}else{$env:PROCESSOR_ARCHITECTURE}
$arch=switch($machineArch){'ARM64'{'arm64'}'AMD64'{'amd64'}default{throw 'A 64-bit Windows system is required.'}}
$programRoot=if($env:ProgramW6432){$env:ProgramW6432}else{$env:ProgramFiles}
$base=Join-Path $programRoot 'PC Inventory Agent'
$existing=Get-Service -Name FlyingFishInventory -ErrorAction SilentlyContinue
$current=if($existing){Get-CimInstance Win32_Service -Filter "Name='FlyingFishInventory'"}else{$null}
$Config=Resolve-InventoryConfig -Config $Config -ServiceCommand $(if($current){$current.PathName}else{''}) -DefaultConfig 'C:\ProgramData\PCInventory\agent.json'
$previousExecutable=Get-InventoryServiceExecutable $(if($current){$current.PathName}else{''})
if(!$ServiceUser){$ServiceUser=if($current){$current.StartName}else{'NT SERVICE\FlyingFishInventory'}}
if($ServiceUser -match '^(LocalSystem|SYSTEM|NT AUTHORITY\\SYSTEM|S-1-5-18)$' -or $ServiceUser -match '(^|\\)Administrator$'){throw 'A low privilege service identity is required.'}
if($current -and $current.StartName -ine $ServiceUser){throw 'ServiceUser must match the current service identity during upgrade.'}
foreach($file in @("inventory-agent-windows-$arch.exe","inventory-launcher-windows-$arch.exe","inventory-browser-host-windows-$arch.exe","inventory-tray-windows-$arch.exe",'install-browser-windows.ps1','windows-install-functions.ps1','native-hosts\chrome.json','native-hosts\edge.json','native-hosts\firefox.json')){
 if(!(Test-Path -LiteralPath (Join-Path $PSScriptRoot $file) -PathType Leaf)){throw 'Release files missing. Extract the full ZIP before installing.'}
}
# Reject redirected paths before any privileged creation.
$currentPath=$Config
while($currentPath){
 $entry=Get-Item -LiteralPath $currentPath -Force -ErrorAction SilentlyContinue
 if($entry -and ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Reparse points are not allowed.'}
 $parent=[IO.Path]::GetDirectoryName($currentPath);if($parent -eq $currentPath){break};$currentPath=$parent
}
if(![IO.Path]::IsPathRooted($Config)){throw 'Configuration path must be absolute.'}
if(!(Test-Path -LiteralPath $Config -PathType Leaf)){
 if($existing){throw 'The existing configuration is missing. Restore it or specify its correct -Config path; no new identity has been generated.'}
 New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($Config)) -Force|Out-Null
 & (Join-Path $PSScriptRoot "inventory-agent-windows-$arch.exe") -config $Config -init-config -server $Server -state-dir (Join-Path ([IO.Path]::GetDirectoryName($Config)) 'state')
 if($LASTEXITCODE -ne 0){throw 'Cannot initialize registration configuration.'}
}
$configuration=Get-Content -LiteralPath $Config -Raw|ConvertFrom-Json
if(![IO.Path]::IsPathRooted($Config) -or ![IO.Path]::IsPathRooted($configuration.state_dir)){throw 'Configuration and state paths must be absolute.'}
foreach($path in @($base,$Config,$configuration.state_dir)){
 $currentPath=$path
 while($currentPath){
  $entry=Get-Item -LiteralPath $currentPath -Force -ErrorAction SilentlyContinue
  if($entry -and ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Reparse points are not allowed in installation/configuration paths.'}
  $parent=[IO.Path]::GetDirectoryName($currentPath)
  if($parent -eq $currentPath){break};$currentPath=$parent
 }
}
# Validate before stopping the existing service or replacing its executable.
& (Join-Path $PSScriptRoot "inventory-agent-windows-$arch.exe") -config $Config -check-config
if($LASTEXITCODE -ne 0){throw 'Invalid configuration; the existing service has not been changed.'}
New-Item -ItemType Directory -Path $base -Force|Out-Null
$installationLock=Enter-InventoryInstallLock -Base $base
Write-Host 'Stopping any existing agent and status icon...'
Stop-InventoryInstallation -Base $base -StateDir $configuration.state_dir -PreviousExecutable $previousExecutable
Write-Host 'Installing the new agent...' 
Copy-Item (Join-Path $PSScriptRoot "inventory-agent-windows-$arch.exe") (Join-Path $base 'inventory-agent.exe') -Force
Copy-Item (Join-Path $PSScriptRoot "inventory-launcher-windows-$arch.exe") (Join-Path $base 'inventory-launcher.exe') -Force
$tray=Join-Path $base 'inventory-tray.exe'
Copy-Item (Join-Path $PSScriptRoot "inventory-tray-windows-$arch.exe") $tray -Force

if($existing){
 Set-InventoryServiceRegistration -Current $current -Executable (Join-Path $base 'inventory-launcher.exe') -Config $Config
}else{
 # A service virtual account needs no password and is unique to this service.
 & (Join-Path $base 'inventory-launcher.exe') -config $Config -service install -service-user $ServiceUser
 if($LASTEXITCODE -ne 0){throw 'Service installation failed. Custom service accounts require service-logon rights.'}
}
# The public trust anchor must be administrator-owned; no ordinary user can replace it.
$bridge=Join-Path $env:ProgramData 'PCInventory\Bridge'
$private=Join-Path $bridge 'private'
foreach($entry in @($bridge,$private,(Join-Path $bridge 'cert.pem'),(Join-Path $private 'key.pem'))){if((Test-Path -LiteralPath $entry) -and ((Get-Item -LiteralPath $entry).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Browser identity cannot use reparse points.'}}
New-Item -ItemType Directory -Path $private -Force|Out-Null
$admins=New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')
foreach($directory in @($bridge,$private)){
 $acl=New-Object Security.AccessControl.DirectorySecurity;$acl.SetAccessRuleProtection($true,$false);$acl.SetOwner($admins)
 foreach($sid in @('S-1-5-18','S-1-5-32-544')){$acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule((New-Object Security.Principal.SecurityIdentifier($sid)),'FullControl','ContainerInherit,ObjectInherit','None','Allow')))}
 if($directory -eq $bridge){$acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule((New-Object Security.Principal.SecurityIdentifier('S-1-5-32-545')),'ReadAndExecute','ContainerInherit,ObjectInherit','None','Allow')))}
 else{$acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($ServiceUser,'ReadAndExecute','ContainerInherit,ObjectInherit','None','Allow')))}
 Set-Acl -LiteralPath $directory -AclObject $acl
}
& (Join-Path $base 'inventory-agent.exe') -init-browser-tls
if($LASTEXITCODE -ne 0){throw 'Browser TLS identity initialization failed.'}
$certificate=Join-Path $bridge 'cert.pem';$certAcl=Get-Acl -LiteralPath $certificate;$certAcl.SetOwner($admins);Set-Acl -LiteralPath $certificate -AclObject $certAcl
New-Item -ItemType Directory -Path $configuration.state_dir -Force|Out-Null
$directoryAcl=New-Object Security.AccessControl.DirectorySecurity
$directoryAcl.SetAccessRuleProtection($true,$false)
foreach($sid in @('S-1-5-18','S-1-5-32-544')){$directoryAcl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule((New-Object Security.Principal.SecurityIdentifier($sid)),'FullControl','ContainerInherit,ObjectInherit','None','Allow')))}
$directoryAcl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($ServiceUser,'Modify','ContainerInherit,ObjectInherit','None','Allow')))
Set-Acl -LiteralPath $configuration.state_dir -AclObject $directoryAcl
# Protect known identity files on upgrades without traversing the offline queue.
foreach($name in @('device-key','identity.lock','status.json')){
 $identityPath=Join-Path $configuration.state_dir $name
 if(Test-Path -LiteralPath $identityPath){
  $entry=Get-Item -LiteralPath $identityPath -Force
  if($entry.PSIsContainer -or ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Device identity must be a regular file.'}
  & icacls.exe $identityPath /reset /Q | Out-Null
  if($LASTEXITCODE -ne 0){throw 'Cannot protect existing identity files.'}
 }
}
$fileAcl=New-Object Security.AccessControl.FileSecurity
$fileAcl.SetAccessRuleProtection($true,$false)
foreach($sid in @('S-1-5-18','S-1-5-32-544')){$fileAcl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule((New-Object Security.Principal.SecurityIdentifier($sid)),'FullControl','Allow')))}
$fileAcl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($ServiceUser,'Read','Allow')))
Set-Acl -LiteralPath $Config -AclObject $fileAcl
& (Join-Path $PSScriptRoot 'install-browser-windows.ps1') -Binary (Join-Path $PSScriptRoot "inventory-browser-host-windows-$arch.exe") -ManifestDirectory (Join-Path $PSScriptRoot 'native-hosts')
# Run the companion per interactive user at logon; the service remains independent.
$run='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'
New-Item -Path $run -Force|Out-Null
New-ItemProperty -Path $run -Name 'PC Inventory Agent' -PropertyType String -Value ('"'+$tray+'"') -Force|Out-Null
$commonPrograms=[Environment]::GetFolderPath('CommonPrograms')
$shortcut=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $commonPrograms 'PC Inventory Agent.lnk'))
$shortcut.TargetPath=$tray;$shortcut.Arguments='-show';$shortcut.WorkingDirectory=$base;$shortcut.Description='Status og manuel synkronisering';$shortcut.Save()
$installationLock.Flush()
Complete-InventoryInstallation -Version $InstallerVersion -Quiet:$Quiet -LaunchTray {
 (New-Object -ComObject Shell.Application).ShellExecute($tray,'','','open',1)
}
Write-Host "PC Inventory Agent $InstallerVersion installed and running. Existing configuration and device identity have been preserved."
$installationLock.Dispose()
exit 0
