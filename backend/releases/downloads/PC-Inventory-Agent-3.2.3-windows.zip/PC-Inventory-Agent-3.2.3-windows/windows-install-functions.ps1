# Shared Windows installer operations. Dot-sourcing this file performs no installation.
function Resolve-InventoryConfig {
 param([string]$Config,[string]$ServiceCommand,[string]$DefaultConfig)
 if($Config){return $Config}
 if($ServiceCommand){
  $match=[regex]::Match($ServiceCommand,'(?:^|\s)-config(?:=|\s+)(?:"([^"]+)"|([^\s"]+))',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
  if(!$match.Success){throw 'Cannot locate the existing agent configuration. Specify -Config explicitly; the existing identity has not been changed.'}
  if($match.Groups[1].Success){return $match.Groups[1].Value};return $match.Groups[2].Value
 }
 return $DefaultConfig
}
function Get-InventoryServiceExecutable {
 param([string]$ServiceCommand)
 if(!$ServiceCommand){return ''}
 $match=[regex]::Match($ServiceCommand,'^\s*(?:"([^"]+)"|([^\s"]+))')
 if(!$match.Success){throw 'Invalid existing service command.'}
 $executable=if($match.Groups[1].Success){$match.Groups[1].Value}else{$match.Groups[2].Value}
 if([IO.Path]::GetExtension($executable) -ine '.exe'){throw 'Invalid or unquoted existing service executable. No program files have been replaced.'}
 return $executable
}
function Test-InventoryProcessPath {
 param([string]$Path,[string]$Base,[string]$StateDir,[string]$PreviousExecutable)
 if(!$Path){return $false}
 try{
  $pathFull=[IO.Path]::GetFullPath($Path)
  $targets=@((Join-Path $Base 'inventory-agent.exe'),(Join-Path $Base 'inventory-launcher.exe'),(Join-Path $Base 'inventory-tray.exe'),(Join-Path $Base 'BrowserHost\inventory-browser-host.exe'))
  if($PreviousExecutable){$targets+=$PreviousExecutable;$targets+=(Join-Path ([IO.Path]::GetDirectoryName($PreviousExecutable)) 'inventory-agent.exe')}
  foreach($target in $targets){if([string]::Equals($pathFull,[IO.Path]::GetFullPath($target),[StringComparison]::OrdinalIgnoreCase)){return $true}}
  $updates=[IO.Path]::GetFullPath((Join-Path $StateDir 'updates'))
  return [string]::Equals([IO.Path]::GetDirectoryName($pathFull),$updates,[StringComparison]::OrdinalIgnoreCase) -and ([IO.Path]::GetFileName($pathFull) -cmatch '^[a-f0-9]{32}\.exe$')
 }catch{return $false}
}
function Get-InventoryInstallationProcesses {
 param([string]$Base,[string]$StateDir,[string]$PreviousExecutable)
 Get-CimInstance Win32_Process | Where-Object { Test-InventoryProcessPath -Path $_.ExecutablePath -Base $Base -StateDir $StateDir -PreviousExecutable $PreviousExecutable }
}
function Stop-InventoryInstallation {
 param([string]$Base,[string]$StateDir,[string]$PreviousExecutable,[int]$TimeoutSeconds=30)
 $service=Get-Service -Name FlyingFishInventory -ErrorAction SilentlyContinue
 if($service -and $service.Status -ne 'Stopped'){
  # ServiceController.Stop returns after the request; the following wait is bounded.
  $service.Stop()
  $service.WaitForStatus('Stopped',[TimeSpan]::FromSeconds($TimeoutSeconds))
  $service.Refresh()
  if($service.Status -ne 'Stopped'){throw 'The existing agent service did not stop. No program files have been replaced.'}
 }
 # This also catches a launcher child running a signed update, or an orphan left
 # by an older launcher. Never terminate processes based on their name alone.
 $timer=[Diagnostics.Stopwatch]::StartNew()
 do{
  $remaining=@(Get-InventoryInstallationProcesses -Base $Base -StateDir $StateDir -PreviousExecutable $PreviousExecutable)
  if($remaining.Count -eq 0){return}
  if($timer.Elapsed.TotalSeconds -ge $TimeoutSeconds){throw 'Existing agent processes did not exit. No program files have been replaced.'}
  foreach($process in $remaining){
   try{$result=Invoke-CimMethod -InputObject $process -MethodName Terminate -ErrorAction Stop;if($result.ReturnValue -ne 0){throw 'Cannot stop an existing agent process.'}}
   catch{
    # A process may exit naturally between enumeration and termination.
    $stillRunning=@(Get-InventoryInstallationProcesses -Base $Base -StateDir $StateDir -PreviousExecutable $PreviousExecutable | Where-Object { $_.ProcessId -eq $process.ProcessId })
    if($stillRunning.Count -gt 0){throw}
   }
  }
  Start-Sleep -Milliseconds 150
 }while($true)
}
function Show-InventoryInstallMessage {
 param([bool]$Success,[string]$Version,[switch]$Quiet)
 if($Success){$message="Agent successfully installed.`r`n`r`nPC Inventory Agent $Version`r`nThe agent service is running. New devices still require approval in ITSM.";$icon='Information'}
 else{$message="Agent installation failed.`r`n`r`nInstallation was not completed. Check the installer window for details before trying again.";$icon='Error'}
 if($Quiet -or ![Environment]::UserInteractive){Write-Host $message;return}
 Add-Type -AssemblyName System.Windows.Forms
 [void][System.Windows.Forms.MessageBox]::Show($message,'PC Inventory Agent','OK',$icon)
}
function Complete-InventoryInstallation {
 param([string]$Version,[scriptblock]$LaunchTray,[switch]$Quiet)
 $service=Get-Service -Name FlyingFishInventory -ErrorAction Stop
 if($service.Status -ne 'Running'){$service.Start()}
 $service.WaitForStatus('Running',[TimeSpan]::FromSeconds(30))
 $service.Refresh()
 if($service.Status -ne 'Running'){throw 'The new agent service did not start.'}
 if($LaunchTray){try{& $LaunchTray}catch{Write-Warning 'Open PC Inventory Agent from Start, or sign out and back in to show the status icon.'}}
 # An installed/running service is distinct from successful online enrollment.
 Show-InventoryInstallMessage -Success $true -Version $Version -Quiet:$Quiet
}

function Enter-InventoryInstallLock {
 param([string]$Base)
 $path=Join-Path $Base '.install.lock'
 if(Test-Path -LiteralPath $path){$item=Get-Item -LiteralPath $path -Force;if($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Invalid installer lock file.'}}
 try{return [IO.File]::Open($path,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}
 catch{throw 'Another installation may already be running, or its lock file is inaccessible. No program files have been replaced.'}
}

function Set-InventoryServiceRegistration {
 param([Parameter(Mandatory=$true)]$Current,[Parameter(Mandatory=$true)][string]$Executable,[Parameter(Mandatory=$true)][string]$Config)
 if($Current.Name -ne 'FlyingFishInventory'){throw 'Unexpected service; registration has not been changed.'}
 if($Executable -match '["\r\n\x00]' -or $Config -match '["\r\n\x00]'){throw 'Invalid character in the service program or configuration path.'}
 $command='"'+$Executable+'" -config "'+$Config+'"'
 # Reinstalling the same launcher does not require a registry mutation. Compare
 # parsed arguments so an unquoted config path without spaces is equivalent.
 $sameProgram=[string]::Equals((Get-InventoryServiceExecutable $Current.PathName),$Executable,[StringComparison]::OrdinalIgnoreCase)
 $sameConfig=[string]::Equals((Resolve-InventoryConfig -ServiceCommand $Current.PathName),$Config,[StringComparison]::OrdinalIgnoreCase)
 if($sameProgram -and $sameConfig -and $Current.StartMode -in @('Auto','Automatic')){return}
 try{
  # Structured CIM arguments avoid PowerShell 5.1/native command-line quoting.
  # Omitted account/password parameters preserve the existing service identity.
  $result=Invoke-CimMethod -InputObject $Current -MethodName Change -Arguments @{PathName=$command;StartMode='Automatic'} -ErrorAction Stop
 }catch{throw "Cannot update the Windows service through CIM: $($_.Exception.Message)"}
 if($null -eq $result -or $null -eq $result.PSObject.Properties['ReturnValue']){throw 'Windows service update returned no result; installation stopped.'}
 $code=[uint32]$result.ReturnValue
 if($code -ne 0){
  $reasons=@{1='operation not supported';2='access denied';3='dependent services are running';5='service cannot accept this operation';7='service request timed out';9='program path not found';11='service database locked';14='service disabled';15='service logon failed';16='service marked for deletion';21='invalid service parameters';22='invalid service account or service-logon rights'}
  $reason=if($code -le 24){$reasons[[int]$code]}else{$null};if(!$reason){$reason='Windows rejected the service change'}
  throw "Windows service update failed: $reason (Win32_Service.Change code $code). Existing device configuration and keys have been preserved."
 }
 $verified=Get-CimInstance Win32_Service -Filter "Name='FlyingFishInventory'" -ErrorAction Stop
 if(!$verified -or ![string]::Equals((Get-InventoryServiceExecutable $verified.PathName),$Executable,[StringComparison]::OrdinalIgnoreCase) -or ![string]::Equals((Resolve-InventoryConfig -ServiceCommand $verified.PathName),$Config,[StringComparison]::OrdinalIgnoreCase) -or $verified.StartMode -notin @('Auto','Automatic')){throw 'Windows reported a successful service change, but verification of its program, configuration or automatic start failed.'}
 if(![string]::Equals($verified.StartName,$Current.StartName,[StringComparison]::OrdinalIgnoreCase)){throw 'The service account changed unexpectedly; installation stopped to protect the device identity.'}
}
