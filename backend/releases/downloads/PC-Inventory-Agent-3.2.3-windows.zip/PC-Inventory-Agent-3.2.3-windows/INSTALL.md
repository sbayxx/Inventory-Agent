# PC Inventory Agent 3.2.3 · Windows og Linux

Disse pakker indeholder agent, launcher til signerede opdateringer, browserhost og registrering til Chrome, Edge og Firefox. Begge 64-bit arkitekturer (x64/amd64 og ARM64) er med; installeren vælger automatisk. Der kræves ikke Python, Go eller .NET-installation på klienten. Agentidentitet og kø bevares ved opgradering.

Efter installation: Kontrollér `agent_id` i den beskyttede `state/status.json` via en betroet kanal, og godkend enheden med korrekt kunde i ITSM → Agentregistrering. Se [registreringsvejledningen](device-enrollment.md).

## Windows

Version 3.2.3 installerer automatisk et statusikon ved Windows-uret. Dobbeltklik for sidste synkronisering, enheds-ID, køstatus og **Synkronisér nu**. Se [statusikonets vejledning](windows-tray.md). Ikonet findes også i Start-menuen som **PC Inventory Agent**; Windows kan skjule det under pilen **^**.

1. Pak hele `PC-Inventory-Agent-3.2.3-windows.zip` ud. Kør ikke direkte inde fra ZIP-filen.
2. Der skal ikke klargøres en nøgle, kode eller JSON-fil. Installeren opretter offentlige indstillinger, og tjenesten opretter sin egen identitet. En eksisterende installation bruger sin eksisterende konfiguration; angiv om nødvendigt dens sti med `-Config`.
3. Dobbeltklik på **Install.cmd**, og godkend Windows’ administratorprompt. Installeren stopper selv den eksisterende agent og statusikonet, genbruger konfiguration og identitet, installerer den nye version og starter tjenesten igen. Når tjenesten kører, vises **Agent successfully installed.** Der skal ikke stoppes noget manuelt. Alternativt kan Windows PowerShell som administrator bruges:

```powershell
.\install-windows.ps1
# Hvis den eksisterende konfiguration ligger et andet sted:
.\install-windows.ps1 -Config 'C:\Eksisterende\agent.json'
```

Scripts skal være tilladt af virksomhedens PowerShell-politik. De ændrer ikke den globale execution policy. På en ny installation bruges en særskilt virtuel servicekonto `NT SERVICE\FlyingFishInventory`, som ikke kræver en adgangskode. En eksisterende servicekonto bevares; en alternativ allerede provisioneret konto kan angives med `-ServiceUser` og skal have service-logon-rettigheder. Kontoen må ikke være LocalSystem eller Administrator.

Installeren beskytter konfiguration og state, installerer tjenesten og registrerer automatisk browserhost i både 32- og 64-bit registryvisningen for Chrome, Edge og Firefox. Ingen browserkonfiguration skal importeres.

Kontrollér tjenesten:

```powershell
Get-Service FlyingFishInventory
Get-Content 'C:\ProgramData\PCInventory\state\status.json'
```

Statusfilens placering følger `state_dir` i agentkonfigurationen. Første scanning kan tage lidt tid. Windows-installationen kræver pilotafprøvning på en Windows-computer; den kan ikke runtimeafprøves på byggemaskinens macOS.

## Linux med systemd

1. Pak `PC-Inventory-Agent-3.2.3-linux.tar.gz` ud, og gå ind i den udpakkede mappe.
2. Der skal ikke klargøres en nøgle, kode eller JSON-fil. Installeren opretter offentlige indstillinger i `/etc/pc-inventory/agent.json` med state i `/var/lib/pc-inventory`. En eksisterende konfiguration og identitet bevares.
3. Kør:

```sh
sudo sh ./install-linux.sh
systemctl status FlyingFishInventory.service
sudo journalctl -u FlyingFishInventory.service -n 50
```

Installeren opretter en begrænset systemkonto, beskytter konfiguration og kø, installerer agent/launcher/browserhost i `/opt/pc-inventory` og aktiverer systemd-tjenesten. Chrome, Chromium, Edge og Firefox får native-host-registrering uden Python og uden manuel browserimport. Systemd er påkrævet. Snap-/Flatpak-browsere kan kræve deres distributions særlige native-messaging-integration; de medfølgende systemregistreringer gælder almindelige browserinstallationer.

Systemd-sandboxen tillader de to ovennævnte state-mapper. Bruger en eksisterende installation en anden mappe, skal administrator tilpasse `ReadWritePaths` og rettigheder før opgraderingen. En eksisterende dedikeret systemd-servicekonto bevares. Flyt ikke en aktiv kø uden en planlagt serviceafbrydelse. Runtime-/servicepilot på Linux er stadig påkrævet.

## Browserudvidelser 1.2.3 · ingen JSON-konfigurationsimport

Installér/opgradér først den konfigurerede computeragent med den medfølgende browserbro. Installér derefter udvidelsen i den enkelte browserprofil:

- **Chrome:** Pak `PC-Inventory-Agent-Web-1.2.3-chrome.zip` ud. Åbn `chrome://extensions`, aktivér udviklertilstand, vælg **Indlæs udpakket**, og vælg den mappe, der indeholder `manifest.json`. Du vælger mappen, ikke en JSON-konfigurationsfil.
- **Edge:** Samme fremgangsmåde med Edge-pakken via `edge://extensions`.
- **Firefox:** Åbn `about:debugging#/runtime/this-firefox`, vælg **Indlæs midlertidig tilføjelse**, og vælg `PC-Inventory-Agent-Web-1.2.3-firefox.xpi`. Der vælges ingen JSON-fil. Denne usignerede udviklerudgave forsvinder ved browsergenstart. Normal permanent installation kræver Mozilla-signering; signaturkontrollen skal ikke slås fra.
- **Safari på macOS:** Kildepakken skal konverteres, bygges og signeres som en Safari-app i fuld Xcode. Den er endnu ikke en installerbar Safari-udvidelse. Safari findes ikke som mål for Windows/Linux-pakkerne.

Udvidelser indeholder tekniske manifestfiler, fordi browserne kræver dem. Brugeren skal hverken redigere dem eller importere `browser.json`, `agent.json`, serveradresser eller tokens i udvidelsen. Nye computeragenter afventer administratorens godkendelse i ITSM; browseren genbruger derefter agentens identitet.

Udvidelsen registrerer nye besøg og sender automatisk domæne, kategori og dagstal via agenten til ITSM cirka hvert 15. minut. Den sender ikke fulde URL'er, browserhistorik eller præcise besøgstidspunkter. Agentens token forbliver i tjenesten. Samme faste extension-ID bevares ved opdatering, så eksisterende browserbroer fortsat godkender udvidelsen.

Åbn udvidelsen → **Automatisk forbindelse til ITSM** → **Send til ITSM nu** for at kontrollere status. Se derefter ITSM → Inventory → computeren → **Webtrafik**. Der bruges ikke en browser-JSON-import eller et login i udvidelsen.

## Verifikation og distribution

Pakkernes SHA-256 står i `PC-Inventory-Agent-3.2.3-SHA256SUMS`; browserarkivernes hashes står under `build/browser-extension/SHA256SUMS`. Alle medfølgende agent-, launcher- og Windows-statusfiler er bygget med version 3.2.3. Der er ikke foretaget ændringer i produktionsdatabasen eller installeret software på byggemaskinen som del af pakningen.

Chrome/Edge-pakkerne er udviklerudgaver, ikke butikspublicerede CRX-pakker. Firefox-XPI'en er ikke Mozilla-signeret. Safari-app, butiksdistribution og konkrete Windows/Linux-installationer kræver de nævnte bygge-/signerings-/pilotskridt.

Pakkeverifikation 20. oktober 2026: agent/launcher/browserhost er verificeret for Windows PE x64/ARM64 og Linux ELF amd64/ARM64. Pakkerne indeholder samme binære filer som de tidligere byggede 3.0.0-artefakter. Manifesternes allowlists matcher de faste extension-ID'er, og der er ingen indlejret agentkonfiguration, miljøfiler eller private nøgler. Linux-installation og browserregistrering er afprøvet i et isoleret simuleret OS for begge arkitekturer; ugyldig konfiguration stopper før serviceafbrydelse. Browserens core/background/serviceworker/sync- og pakkertests består. Der er ikke startet rigtige Windows-/Linux-tjenester eller installeret udvidelser i brugerens browsere under denne kontrol.

Sikkerhedsudgave 3.2.2 initialiserer nu et certifikat pr. enhed til den lokale browserbro. Den offentlige certifikatfil er skrivebeskyttet for almindelige brugere; privatnøglen kan kun læses af tjenesten og administrator. Browserhost validerer certifikatet og går aldrig tilbage til HTTP. Opgradér derfor med hele installationspakken, ikke kun agentens EXE/binærfil. Certifikat og privatnøgle oprettes ved installation og er ikke indeholdt i ZIP/tar/PKG.
