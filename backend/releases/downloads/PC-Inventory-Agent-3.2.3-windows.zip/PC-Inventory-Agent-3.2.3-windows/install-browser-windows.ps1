#Requires -RunAsAdministrator
param([Parameter(Mandatory=$true)][string]$Binary,[string]$ManifestDirectory=(Join-Path $PSScriptRoot 'native-hosts'))
$ErrorActionPreference='Stop'
$programRoot=if($env:ProgramW6432){$env:ProgramW6432}else{$env:ProgramFiles}
$base=Join-Path $programRoot 'PC Inventory Agent\BrowserHost'
if((Test-Path -LiteralPath $base) -and ((Get-Item -LiteralPath $base).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Reparse point not allowed.'}
foreach($browser in @('chrome','edge','firefox')){if(!(Test-Path -LiteralPath (Join-Path $ManifestDirectory "$browser.json"))){throw 'Native-host templates missing. Extract the full installation ZIP.'}}
New-Item -ItemType Directory -Force -Path $base|Out-Null
$target=Join-Path $base 'inventory-browser-host.exe'
Copy-Item -LiteralPath $Binary -Destination $target -Force
foreach($browser in @('chrome','edge','firefox')){
 $manifest=Get-Content -LiteralPath (Join-Path $ManifestDirectory "$browser.json") -Raw|ConvertFrom-Json
 if($manifest.name -ne 'dk.flyingfish.inventory.browser' -or $manifest.type -ne 'stdio'){throw 'Unexpected native host template.'}
 $manifest.path=$target
 $file=Join-Path $base "$browser.json"
 [IO.File]::WriteAllText($file,($manifest|ConvertTo-Json -Depth 5),(New-Object Text.UTF8Encoding($false)))
 $vendor=switch($browser){'chrome'{'Google\Chrome'}'edge'{'Microsoft\Edge'}'firefox'{'Mozilla'}}
 # Chromium checks the 32-bit view first; register the same allowlist in both views.
 foreach($view in @([Microsoft.Win32.RegistryView]::Registry32,[Microsoft.Win32.RegistryView]::Registry64)){
  $registry=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine,$view)
  try{$entry=$registry.CreateSubKey("SOFTWARE\$vendor\NativeMessagingHosts\dk.flyingfish.inventory.browser");try{$entry.SetValue('',$file,[Microsoft.Win32.RegistryValueKind]::String)}finally{$entry.Dispose()}}finally{$registry.Dispose()}
 }
}
Write-Host 'Browser bridge registered for Chrome, Edge and Firefox. No browser configuration import is needed.'
