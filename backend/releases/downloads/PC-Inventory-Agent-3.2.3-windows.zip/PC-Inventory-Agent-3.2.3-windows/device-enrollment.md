# Automatisk agentregistrering · version 3.1.0

Brugeren installerer agenten og indtaster ingen nøgle eller kode. Installeren opretter en konfiguration med offentlige indstillinger; tjenesten opretter sin egen P-256-enhedsidentitet. Nye enheder vises under **ITSM → Inventory → Agentregistrering**. Før godkendelse sender agenten kun offentlig nøgle, computernavn og platform til registreringsendepunktet. Den indsamler endnu ikke inventar, åbner ikke browserbroen og udfører ingen fjernopgaver.

En global administrator kontrollerer det lokale enheds-ID via en betroet kanal, vælger kunde og godkender én gang. Computernavn, IP og serienummer må aldrig bruges som selvstændigt identitetsbevis. Kontrol af et ID kopieret fra samme serverliste er ikke en uafhængig kontrol. Kundeadministratorer har ikke adgang til den fælles liste over endnu ikke tildelte enheder.

## Aktivering på serveren

Udgiv serverfilerne sammen, og kør den additive migration mod inventory-databasen:

```sh
php server/bin/inventory.php enrollment-migrate
```

Migrationen opretter tabeller til offentlige nøgler, replaybeskyttelse og godkendelseslog samt request-budgettabellen, hvis den mangler. Eksisterende agenter og inventar ændres ikke. Migrationen kan gentages. Registrering er som udgangspunkt slået fra.

Serverens PHP skal have OpenSSL med EC/P-256-understøttelse samt de eksisterende PDO/MySQL-funktioner. Sodium og klientcertifikater ved TLS-proxyen er ikke nødvendige. Agentens HTTPS-certifikatkontrol er fortsat obligatorisk. De offentlige indgangsfiler `enroll.php` og `enrollments.php` skal ligge ved siden af de eksisterende API-filer; backend og migrationer skal fortsat være HTTP-beskyttede.

Den eksisterende deployhjælper har fået trin `enrollment` med backup af erstattede filer. Udgivelsen er ikke udført som en del af den lokale implementering. Kør migrationen, før nye klienter tages i brug. Legacy bearer-klienter kan fortsætte under udrulningen.

Åbn **Agentregistrering** som global administrator, og aktivér **Tillad registrering af nye agenter**. Hovedkontakten til Inventory skal også være aktiv. Registrering er uafhængig af Version 3-hovedkontakten. Hvis nyregistrering slås fra, kan allerede godkendte agenter stadig bekræfte deres status og starte efter genstart.

## Installation og godkendelse

Windows:

1. Udpak hele `PC-Inventory-Agent-3.1.0-windows.zip`.
2. Kør `install-windows.ps1` som administrator. Ingen konfigurationsfil skal klargøres. En alternativ HTTPS-server kan angives med `-Server`; standard er `https://itsm.governit.dk/inventory`.
3. Læs `C:\ProgramData\PCInventory\state\status.json` som administrator. Kontrollér `agent_id` på den konkrete PC via en betroet kanal.
4. Find det samme ID i ITSM, vælg den rette kunde, bekræft kontrollen og godkend. Agenten forsøger igen ca. hvert 60–75 sekund og begynder derefter normal drift.

Den virtuelle servicekonto kræver ingen adgangskode. Den private nøgle oprettes af tjenesten, aldrig af installationsprocessen, og DPAPI krypterer den under tjenestens egen Windows-identitet. Skift af servicekonto kræver særskilt migrering; en anden konto kan ikke uden videre dekryptere nøglen.

Linux: Udpak 3.1.0-pakken, og kør `sudo sh ./install-linux.sh`. Se `/var/lib/pc-inventory/status.json` og godkend i ITSM. Alternativ server vælges med `sudo env INV_SERVER=https://example.org/inventory sh ./install-linux.sh` ved første installation.

macOS: Installer `PC-Inventory-Agent-3.1.0-universal.pkg`. Tjenesten starter automatisk. Åbn **PC Inventory Agent** for at vise enheds-ID; der skal ikke importeres en fil. Standardstate er `/Library/Application Support/FlyingFishInventory/state`.

Agentens tekniske `agent.json` eksisterer stadig, men nye konfigurationer indeholder ingen token eller privat nøgle. Installeren erstatter aldrig en eksisterende konfiguration. Gamle tokenbaserede installationer bruger fortsat deres oprindelige identitet og skal ikke godkendes igen.

## Identitet og adgang

- P-256-nøglepar genereres med operativsystemets kryptografiske tilfældighedskilde. Enheds-ID er de første 128 bit af SHA-256 over den offentlige PKIX-nøgle.
- Hver anmodning signerer agent-ID, operation, SHA-256 af den præcise body, tidspunkt og en ny tilfældig 128-bit nonce. Go bruger ECDSA/ASN.1; PHP verificerer med OpenSSL/SHA-256.
- Serveren accepterer højst fem minutters tidsafvigelse. En brugt nonce kan ikke anvendes igen; en unik databasebegrænsning håndhæver dette også ved samtidige kald. Nonces gemmes i 660 sekunder og ryddes løbende.
- Identiteten gælder alle agentfunktioner: inventar, browserbro, fjernopgaver, opdateringskontrol og download. HTTPS, signaturkontrol af opdateringer, kundeadskillelse og eksisterende begrænsede servicekonti bevares.
- Serveren modtager og gemmer kun offentlig nøgle. En tilfældig, kasseret tokenhash udfylder den eksisterende agenttabel; den giver ingen udleveret bearer-adgang. Browserprofilernes interne tokens udleveres heller ikke til browseren.
- Windows bruger DPAPI under servicekontoen og beskyttede ACL'er. macOS/Linux bruger servicekontoens mappe med mode 0700 og nøglefil med mode 0600. TPM/Keychain er ikke integreret i denne udgave. Diskkryptering anbefales som i den eksisterende installation. En lokal administrator kan stadig kompromittere en kørende agent.
- Der udstedes ikke udløbende enhedscertifikater eller adgangstokens i dette flow, så brugeren skal ikke forny noget. Automatisk rotation af det langsigtede nøglepar og Intune/PKI-baseret førstegangsgodkendelse er ikke implementeret.

**Spær enhed** afviser efterfølgende kald til alle agent-API'er. Allerede accepteret/igangværende arbejde kan afsluttes. Godkendelse, afvisning og spærring registreres med administrator, tidspunkt, kunde og enheds-ID. Afviste/spærrede identiteter kan ikke genregistrere sig selv eller ophæve spærringen. En geninstallation skal bevare state, hvis identitet og inventarhistorik skal bevares. Sletning af nøglen giver en ny identitet og kræver en ny, uafhængig godkendelse.

## Registreringsgrænser og drift

Registrering accepterer højst 4 KiB pr. anmodning, 300 kald pr. socket-IP pr. minut og 3000 globalt pr. minut. Forwarding-headere bruges ikke som identitet. Bag en TLS-proxy kan alle agenter derfor dele ét IP-budget; tilpas proxy-/driftsopsætningen ved store installationer. Der kan højst være 1000 ventende registreringer inklusive udløbne. En ventende registrering udløber efter 7 dage og kan derefter kun afvises; den forlænges ikke ved polling. Afvis udløbne eller uvedkommende registreringer for at frigøre plads.

En beskadiget nøgle erstattes aldrig automatisk. Ret årsagen og kontrollér backup/ACL/servicekonto. Et ur med mere end fem minutters afvigelse medfører afvisning; ret tidsynkronisering. Serverfejl giver gentagne registreringsforsøg med pause, og enheds-ID findes stadig lokalt i statusfilen. Den normale offlinekø og seneste inventar bevares ved kommunikationsfejl.

## Verifikation

- `go test -race ./...`: herunder identitetsbevarelse, fejl ved beskadiget nøgle, eksklusiv konfigurationsoprettelse, registreringsstatus og verifikation af Go-genererede signaturer i PHP.
- `server/tests/device-enrollment.php`: isoleret lokal MySQL-test af migration, godkendelse, kundevalg, CSRF, udløb, signaturer, replay, spærring og legacy bearer-adgang.
- `server/tests/device-enrollment-http.py` med `enrollment-router.php`: loopback-test med reel ITSM Auth, godkendelsesformular, HTML-escaping og signerede uploads af inventar/browserdata samt kontrol-/opdateringskald. Routeren må aldrig udgives.
- Testdatabasen skal være en ny tom `inventory_enrollment_test_20261028` på `/tmp/mysql.sock`, med standardtegnsæt `latin1_swedish_ci` som projektets oprindelige tabeller. Testene indeholder en hård DSN-kontrol. Brug kun syntetiske testbrugere og kunder.
- Pakker krydskompileres til Windows/Linux/macOS, x64 og ARM64. Linux-installeren afprøves i et simuleret filsystem; macOS-pakken verificeres uden installation.

Windows DPAPI/servicekonto/ACL, Linux systemd og en reel macOS-installation/genstart kræver fortsat pilot på målmaskinerne. Ingen tjeneste eller systemkonto installeres på byggemaskinen af testene. Pakkerne er fortsat pilotbyg uden Windows Authenticode eller Apple Developer ID/notarisering.
