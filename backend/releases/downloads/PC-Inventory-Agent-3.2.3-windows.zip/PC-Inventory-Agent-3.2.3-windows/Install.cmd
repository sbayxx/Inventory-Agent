@echo off
powershell.exe -NoProfile -File "%~dp0setup-windows.ps1" %*
set "PC_INVENTORY_INSTALL_EXIT=%errorlevel%"
if not "%PC_INVENTORY_INSTALL_EXIT%"=="0" pause
exit /b %PC_INVENTORY_INSTALL_EXIT%
