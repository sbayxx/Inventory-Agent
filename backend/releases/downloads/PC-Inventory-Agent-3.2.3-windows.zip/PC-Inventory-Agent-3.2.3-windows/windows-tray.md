# Windows-statusikon · PC Inventory Agent 3.2.3

Windows-pakken indeholder nu et selvstændigt statusikon ved uret, både til ARM64 og x64. Installer hele `PC-Inventory-Agent-3.2.3-windows.zip` ved at dobbeltklikke på **Install.cmd** og godkende Windows’ administratorprompt. `install-windows.ps1` kan også køres direkte fra en administrator-PowerShell. En eksisterende konfiguration, enhedsidentitet og offlinekø bevares.

Installeren registrerer statusikonet til automatisk start ved brugerens Windows-login og tilføjer **PC Inventory Agent** i Start-menuen. Den forsøger også at starte ikonet i den aktuelle brugers session via Explorer. Hvis det ikke vises med det samme, åbnes det fra Start-menuen. Windows kan placere nye ikoner under pilen **^** ved uret; brugeren kan flytte det frem. Vinduet kræver ikke administratorrettigheder.

Dobbeltklik på ikonet for at åbne vinduet. Højreklik giver **Åbn PC Inventory Agent**, **Synkronisér nu** og **Afslut statusikon (agenten fortsætter)**. Vindueskrydset og **Skjul** skjuler kun vinduet. Agenttjenesten fortsætter også, hvis statusikonet afsluttes, eller brugeren logger ud.

## Oplysninger i vinduet

- Registreringsstatus: kontrollerer, afventer godkendelse, godkendt, afvist/spærret eller udløbet.
- Sidste vellykkede synkronisering, seneste lokale scanning og seneste forsøg.
- Næste planlagte automatiske scanning og antal scanninger, som venter i offlinekøen.
- Serveradresse, enheds-ID, agentversion og statusikonets version.
- Igangværende synkronisering, fejlbesked og resultat af manuel synkronisering.

Tider vises i Windows-brugerens lokale tidszone. Status opdateres cirka hvert femte sekund. Grøn betyder, at tjenesten svarer, enheden er godkendt, og mindst én levering er bekræftet. Gul bruges under opstart, registrering og synkronisering; rød bruges ved fejl eller manglende svar fra tjenesten. En tidligere vellykket synkronisering er ikke en garanti for netadgang lige nu.

Tidsstemplet for vellykket levering gemmes, når serveren kvitterer for en scanning. Det overlever genstart og opdateres også ved fjernopgaver fra ITSM og ved delvis levering af en kø. En delvis levering kan derfor vise både en nylig vellykket levering og resterende ventende scanninger/fejl.

## Manuel synkronisering

**Synkronisér nu** beder den kørende tjeneste om at vågne, indsamle en ny scanning og sende køen til den konfigurerede server. Der startes ikke en ekstra agentproces. Gentagne klik samles til én anmodning; en igangværende synkronisering genbruges. Der er mindst 30 sekunder mellem nye manuelle anmodninger. Synkronisering kræver godkendt registrering. Offline- og leveringsfejl bevarer køen og vises i vinduet; tjenesten forsøger automatisk igen.

Registreringsflowet og serverkravene fra 3.1.0 gælder stadig. Statusikonet kan vise fejl/afventende registrering, selv om de nye serverendepunkter endnu ikke er aktiveret. Vinduet giver ikke mulighed for at ophæve en spærring.

## Lokal sikkerhed og installation

Statusikonet læser ikke `agent.json`, nøglefilen eller offlinekøens indhold. Det kommunikerer med tjenesten via en lokal Windows named pipe med kun to operationer: `status` og `sync`. Pipe-ACL'en tillader lokale brugere at læse status og anmode om sync, men giver dem ikke rettighed til at oprette serverinstanser. Netværksklienter afvises eksplicit. Der åbnes ingen ny TCP-port, og intet nyt server-API er nødvendigt til statusikonet.

Klienten sammenligner pipens ejer med den servicekonto, Windows Service Control Manager har registreret for `FlyingFishInventory`. Den sender først sin anmodning efter denne kontrol. En almindelig bruger kan derfor ikke efterligne tjenesten ved at oprette en pipe med samme navn. Tjenesten reserverer desuden navnet ved første instans og beholder sine fire instanser åbne. Tidsgrænser og størrelsesgrænser beskytter mod lokale klienter, som hænger eller sender ugyldige beskeder. Pipeklienten tillader ikke impersonering ud over identifikationsniveau.

Protokollen indeholder ingen tokens, private nøgler, konfigurationsstier, filvalg, serverændringer eller shellkommandoer. Kun den eksisterende tjeneste bruger enhedsidentiteten til HTTPS-upload. Tjenestens konto og beskyttede ACL'er bevares.

Kildegrundlag for pipe-adgang: [Microsofts dokumentation om navngivne pipes](https://learn.microsoft.com/en-us/windows/win32/devnotes/nt-create-named-pipe-file) og [pipe-adgangstilstande](https://github.com/MicrosoftDocs/win32/blob/docs/desktop-src/ipc/named-pipe-open-modes.md).

Den nye tray-binær installeres som `C:\Program Files\PC Inventory Agent\inventory-tray.exe`. Autostart ligger under `HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run`, værdien **PC Inventory Agent**. Start-genvejen peger på samme binær med `-show`. En installeropgradering lukker kun denne installations tray-processer før erstatning. Tjenesten opgraderes som hidtil.

Launcheren opdaterer fortsat kun agentprocessen automatisk. Statusikonet og dets autostart installeres/opgraderes med Windows-pakken. macOS-opsætningsappen og Linux har ikke fået et tray-ikon i denne version.

## Verifikation og pilot

Runner-testen verificerer, at en manuel anmodning faktisk vækker den sovende agent og laver en ny scanning/levering; en mislykket manuel upload bevarer køen og sidste succes. Platformuafhængige tests dækker tilladte operationer, afvisning før godkendelse, samtidige/manuelle anmodninger, ratebegrænsning, tidsstempelbevarelse og fravær af legitimationsoplysninger i svar. Windows-tests i `agent/internal/desktop/ipc_windows_test.go` afprøver roundtrip, forkert pipe-ejer, genforbindelser og begrænset nedlukning; de skal køres på Windows. Statusikon og agent krydskompileres til ARM64 og amd64 uden CGO, WebView, .NET eller ekstra klientruntime.

En reel Windows-pilot skal kontrollere ikonet, DPI/tekstlayout, normal bruger uden elevation, pipe-ACL/ejervalidering under den faktiske servicekonto, manuel scanning/levering, servicegenstart og Explorer-genstart. Pakken er fortsat en pilot uden Authenticode-signering. Serverændringerne til førstegangsregistrering er ikke lagt i drift som led i tray-arbejdet.

## Automatisk opgradering og installationskvittering · 3.2.2

Installeren finder eksisterende `-config` i Windows-tjenestens registrering, hvis en sti ikke er angivet eksplicit. Dermed genbruges også installationer med en anden konfigurationssti end standarden. En ukendt eksisterende konfiguration giver en fejl før tjenesten stoppes; der udstedes ikke automatisk en ny identitet.

Efter validering låses installationen mod samtidige installere. Tjenesten stoppes med en afgrænset ventetid. Derefter afsluttes eventuelle efterladte agent-, launcher-, browserhost- og tray-processer fra netop denne installation, inklusive signerede opdateringsprocesser i dens beskyttede `state/updates`-mappe. Andre programmer med samme filnavn afsluttes ikke. Programfiler erstattes først, når disse processer er væk.

Tjenesten startes og afventes til **Running**, hvorefter statusikonet forsøges startet. Til sidst vises **Agent successfully installed.** Pop-up'en bekræfter lokal installation og tjenestestart; den er ikke en kvittering for servergodkendelse eller online-synkronisering. Ved installationsfejl vises en fejlbesked og exitkode 1 i stedet. Ingen succesbesked vises ved en mislykket tjenestestart. `install-windows.ps1 -Quiet` undertrykker de interaktive beskeder ved administreret udrulning fra en allerede forhøjet proces. `Install.cmd` er det interaktive forløb. Installeren ændrer ikke PowerShell execution policy.

Installationen rydder ikke konfiguration, nøgler, kø eller inventarhistorik. En fejl efter filudskiftning kan efterlade tjenesten stoppet; der er ikke fuld transaktionsrollback af programfiler, ACL'er og browserregistrering. Genkør den fulde pakke efter fejlen er rettet. Native Windows-pilot skal fortsat kontrollere UAC, processtop og den faktiske pop-up.

## Rettelse af serviceopgradering · 3.2.2

Version 3.2.1 kunne stoppe med `Service upgrade failed; existing service registration retained.` efter filkopiering. Den gamle rutine sendte en citeret kommandolinje gennem PowerShell til `sc.exe` og skjulte fejloutputtet, så den præcise Windows-fejl ikke fremgik.

3.2.2 genbruger en eksisterende registrering, når launcher, konfigurationssti og automatisk start allerede er korrekte. Hvis noget skal ændres, bruges `Win32_Service.Change` med strukturerede CIM-argumenter, og registreringen læses tilbage og verificeres. Servicekonto og adgangskode sendes ikke med ændringen. Fejl viser nu Windows' returkode og årsag. Kommandoer med mellemrum og danske tegn er dækket af regressionstestene.

Efter en mislykket 3.2.1-opgradering skal den fulde 3.2.2-pakke udpakkes i en ny mappe og køres via **Install.cmd**. Installer ikke ved at blande filer fra de to pakker. Der skal ikke afinstalleres, slettes state eller udstedes en ny identitet. Den eksisterende tjeneste kan være stoppet efter den gamle fejl; den nye installer starter den igen efter en vellykket opgradering.

API-reference: [Microsoft: Win32_Service.Change](https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/change-method-in-class-win32-service).
