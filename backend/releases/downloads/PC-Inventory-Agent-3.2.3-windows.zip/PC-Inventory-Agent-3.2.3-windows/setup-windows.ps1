# Interactive entry point. Request elevation without changing execution policy.
#Requires -Version 5.1
param([string]$Server='https://itsm.governit.dk/inventory',[string]$ServiceUser='',[string]$Config='',[switch]$Quiet)
$ErrorActionPreference='Stop'
function Quote-SetupArgument([string]$Value){
 if($Value -match '["\r\n\x00]'){throw 'An installation argument contains an invalid character.'}
 # A trailing backslash must be doubled before the Windows closing quote.
 return '"'+[regex]::Replace($Value,'(\\+)$','$1$1')+'"'
}
try{
 $installer=Join-Path $PSScriptRoot 'install-windows.ps1'
 $helper=Join-Path $PSScriptRoot 'windows-install-functions.ps1'
 if(!(Test-Path -LiteralPath $installer -PathType Leaf) -or !(Test-Path -LiteralPath $helper -PathType Leaf)){throw 'Extract the full ZIP before installing.'}
 $administrator=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
 if($administrator.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
  & $installer @PSBoundParameters
  exit $LASTEXITCODE
 }
 $arguments=@('-NoProfile','-File',(Quote-SetupArgument $installer))
 foreach($name in @('Server','ServiceUser','Config')){if($PSBoundParameters.ContainsKey($name)){$arguments+=('-'+$name);$arguments+=(Quote-SetupArgument ([string]$PSBoundParameters[$name]))}}
 if($Quiet){$arguments+='-Quiet'}
 $process=Start-Process -FilePath (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe') -ArgumentList ($arguments -join ' ') -Verb RunAs -Wait -PassThru
 exit $process.ExitCode
}catch{
 Write-Error -ErrorRecord $_ -ErrorAction Continue
 if(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'windows-install-functions.ps1')){. (Join-Path $PSScriptRoot 'windows-install-functions.ps1');Show-InventoryInstallMessage -Success $false -Version '3.2.2' -Quiet:$Quiet}
 exit 1
}
