globalThis.PCInventoryBrowser = "edge";
