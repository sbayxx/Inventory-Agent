globalThis.PCInventoryBrowser = "chrome";
